document.getElementById('startScrapingButton').addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    chrome.tabs.sendMessage(tabs[0].id, { action: 'startScraping' }, response => {
      if (response.success) {
        updateStatus();
      }
    });
  });
});

document.getElementById('scrapeInnerPageButton').addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    chrome.tabs.sendMessage(tabs[0].id, { action: 'scrapeInnerPage' }, response => {
      if (response.success) {
        updateStatus();
      }
    });
  });
});

document.getElementById('exportToCSVButton').addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    chrome.tabs.sendMessage(tabs[0].id, { action: 'exportToBase64Txt' }, response => {
      if (response.success) {
        // Remove alert message
      }
    });
  });
});

document.getElementById('clearLocalStorageButton').addEventListener('click', () => {
  if (confirm('Are you sure you want to clear all local storage data?')) {
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      chrome.tabs.sendMessage(tabs[0].id, { action: 'clearLocalStorage' }, response => {
        if (response.success) {
          updateStatus(true);
        }
      });
    });
  }
});

document.getElementById('markScrapedRowsButton').addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    chrome.tabs.sendMessage(tabs[0].id, { action: 'markScrapedRows' }, response => {
      if (response.success) {
        // Remove alert message
      }
    });
  });
});

function updateStatus(clear = false) {
  if (clear) {
    document.getElementById('extensionStatus').innerText = 'Rows in local storage: 0, Last scraped row: None';
  } else {
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      chrome.tabs.sendMessage(tabs[0].id, { action: 'getStatus' }, response => {
        if (response) {
          const statusElement = document.getElementById('extensionStatus');
          const lastScrapedRow = response.lastScraped ? `Row Number: ${response.lastScraped.rowNumber}, Identifier: ${response.lastScraped.identifier}, Timestamp: ${response.lastScraped.timestamp}` : 'None';
          statusElement.innerText = `Rows in local storage: ${response.dataCount}, Last scraped row: ${lastScrapedRow}`;
        }
      });
    });
  }
}

// Initial status update
updateStatus();