function sanitizeData(value) {
  return value.replace(/,/g, '');
}

function logTableRows() {
  const rows = document.querySelectorAll('#ContentUsersPage_DgrList tr.row1');
  const headers = getTableHeaders();
  let data = JSON.parse(localStorage.getItem('scrapedData')) || [];
  rows.forEach((row, index) => {
    const cells = row.querySelectorAll('td');
    const rowData = Array.from(cells).map(cell => sanitizeData(cell.innerText.trim()));
    rowData.push(new Date().toLocaleString().replace(/,/g, '')); // Timestamp for row scraped
    const numShuma = rowData[3];

    if (!data.some(existingRow => existingRow[3] === numShuma)) {
      data.push(rowData);
    }
  });
  saveDataToLocalStorage(data);
  markScrapedRows(); // Update table status after scraping
}

function getTableHeaders() {
  const headerRow = document.querySelector('#ContentUsersPage_DgrList tr.table_title');
  const headers = Array.from(headerRow.querySelectorAll('td')).map(header => header.innerText.trim());
  headers.push('Row Scrape Timestamp');
  return headers;
}

function saveDataToLocalStorage(data) {
  localStorage.setItem('scrapedData', JSON.stringify(data));
  localStorage.setItem('scrapedDataCount', data.length);
}

function scrapeInnerPage() {
  const masLetashlum = sanitizeData(document.getElementById('ContentUsersPage_lblMasLetashlum')?.innerText.trim());
  const ptorHelki = sanitizeData(document.getElementById('ContentUsersPage_lblPtorHelki')?.innerText.trim());
  const nameMeytzeg = sanitizeData(document.getElementById('ContentUsersPage_uscPrtShuma1_LblNameMeytzeg')?.innerText.trim());
  const gushHelka = sanitizeData(document.getElementById('ContentUsersPage_uscPrtShuma1_lblGushHelka')?.innerText.trim());
  const sugNechesSvc = sanitizeData(document.getElementById('ContentUsersPage_lblSugNechesSvc')?.innerText.trim());
  const firstRowColumn = sanitizeData(document.querySelector('#ContentUsersPage_dgrHishuvSvc2 tr:nth-child(1) td')?.innerText.trim());
  const numShuma = sanitizeData(document.querySelector('#ContentUsersPage_uscPrtShuma1_LblNumShuma')?.innerText.trim());

  // Scrape the table data
  const table = document.getElementById('ContentUsersPage_dgrHishuvSvc2');
  const tableData = [];
  
  // Get headers
  const tableHeaders = Array.from(table.querySelectorAll('tr.table_title td')).map(header => 
    sanitizeData(header.innerText.trim())
  );
  
  // Get all rows
  const tableRows = table.querySelectorAll('tr.row1');
  tableRows.forEach(row => {
    const rowData = Array.from(row.querySelectorAll('td')).map(cell => 
      sanitizeData(cell.innerText.trim())
    );
    tableData.push(rowData);
  });

  const innerPageData = {
    masLetashlum,
    ptorHelki,
    nameMeytzeg,
    gushHelka,
    sugNechesSvc,
    firstRowColumn,
    numShuma,
    tableHeaders,
    tableRows: tableData,
    innerPageTimestamp: new Date().toLocaleString().replace(/,/g, '')
  };

  let data = JSON.parse(localStorage.getItem('scrapedData')) || [];
  let found = false;
  data = data.map(row => {
    if (row[3] === numShuma) {
      row = [...row, ...Object.values(innerPageData), 'innerPageScraped'];
      found = true;
      localStorage.setItem('lastScrapedRow', JSON.stringify({ rowNumber: row[0], identifier: numShuma, timestamp: row[row.length - 2] }));
    }
    return row;
  });

  if (!found) {
    alert('Error: No matching row found in local storage for the inner page data.');
  } else {
    localStorage.setItem('scrapedData', JSON.stringify(data));
  }
}

function exportToBase64Txt() {
  const data = JSON.parse(localStorage.getItem('scrapedData')) || [];
  const headers = getTableHeaders().concat([
    'masLetashlum', 'ptorHelki', 'nameMeytzeg', 'gushHelka', 'sugNechesSvc', 
    'firstRowColumn', 'numShuma', 'tableHeaders', 'tableRows', 'Inner Page Scrape Timestamp'
  ]);
  const csvData = data.map(row => {
    // Filter out 'innerPageScraped' and handle table data
    return row.filter(value => value !== 'innerPageScraped').map(value => {
      // If the value is an array (table data), stringify it
      if (Array.isArray(value)) {
        return JSON.stringify(value).replace(/"/g, '""');
      }
      return value;
    });
  });
  
  const csvContent = [headers.join(','), ...csvData.map(row => row.join(','))].join('\n');
  const base64Content = btoa(unescape(encodeURIComponent(csvContent)));
  const blob = new Blob([base64Content], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'scrapedData.txt';
  a.click();
}

function clearLocalStorage() {
  localStorage.clear();
  clearRowColors(); // Clear row colors when local storage is cleared
}

function clearRowColors() {
  const rows = document.querySelectorAll('#ContentUsersPage_DgrList tr.row1');
  rows.forEach((row) => {
    row.querySelectorAll('td')[0].style.backgroundColor = ''; // Remove background color
  });
}

function markScrapedRows() {
  const data = JSON.parse(localStorage.getItem('scrapedData')) || [];
  const rows = document.querySelectorAll('#ContentUsersPage_DgrList tr.row1');
  rows.forEach((row) => {
    const numShuma = row.querySelectorAll('td')[3].innerText.trim();
    const existingRow = data.find(existingRow => existingRow[3] === numShuma);
    if (existingRow) {
      if (existingRow.includes('innerPageScraped')) {
        row.querySelectorAll('td')[0].style.backgroundColor = 'green';
      } else {
        row.querySelectorAll('td')[0].style.backgroundColor = 'yellow';
      }
    }
  });
}

// Listener for messages from the popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'startScraping') {
    logTableRows();
    sendResponse({ success: true });
  } else if (request.action === 'scrapeInnerPage') {
    scrapeInnerPage();
    sendResponse({ success: true });
  } else if (request.action === 'exportToBase64Txt') {
    exportToBase64Txt();
    sendResponse({ success: true });
  } else if (request.action === 'clearLocalStorage') {
    clearLocalStorage();
    sendResponse({ success: true });
  } else if (request.action === 'markScrapedRows') {
    markScrapedRows();
    sendResponse({ success: true });
  } else if (request.action === 'getStatus') {
    const dataCount = localStorage.getItem('scrapedDataCount');
    const lastScraped = JSON.parse(localStorage.getItem('lastScrapedRow'));
    sendResponse({ dataCount, lastScraped });
  }
});

document.addEventListener('readystatechange', () => {
  if (document.readyState === 'complete') {
    markScrapedRows();
  }
});